import { AnimatedButton } from "@/components/ui/AnimatedButton";
import { FeatureCard } from "@/components/ui/FeatureCard";
import { SectionContainer } from "@/components/ui/SectionContainer";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Sword, 
  Zap, 
  Users, 
  Trophy, 
  Play, 
  MessageCircle,
  Youtube,
  ExternalLink
} from "lucide-react";

export default function AnimeClashBattleground() {
  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-x-hidden">
      {/* Hero Section */}
      <SectionContainer background="gradient" className="relative min-h-screen flex items-center justify-center">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-32 h-32 bg-blue-500/20 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-40 h-40 bg-purple-500/20 rounded-full blur-xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-cyan-500/10 rounded-full blur-2xl animate-pulse delay-500"></div>
        </div>

        <div className="relative z-10 text-center max-w-6xl mx-auto">
          {/* Game Logo Placeholder */}
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <div className="w-80 h-40 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/50">
                <h1 className="text-4xl font-black text-white text-center leading-tight">
                  ANIME CLASH<br />
                  <span className="text-cyan-300">BATTLEGROUND</span>
                </h1>
              </div>
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl blur opacity-30 animate-pulse"></div>
            </div>
          </div>

          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-500/50 px-4 py-1 text-sm font-semibold">
              🔥 NOW LIVE ON ROBLOX 🔥
            </Badge>
            
            <h2 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent leading-tight">
              The Ultimate Anime Fighting Experience
            </h2>
            
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Master legendary anime abilities, battle epic bosses, and prove your strength in the most intense 
              fighting game on Roblox. Choose your fighter and dominate the battlefield!
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8">
              <AnimatedButton 
                href="https://www.roblox.com/games/placeholder" 
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold px-8 py-4 text-lg"
                glowColor="blue"
              >
                <Play className="mr-2 h-5 w-5" />
                PLAY NOW
              </AnimatedButton>
              
              <AnimatedButton 
                href="https://discord.gg/BNMjDbmVRH"
                variant="outline"
                size="lg"
                className="border-purple-500 text-purple-300 hover:bg-purple-500/20 font-bold px-8 py-4 text-lg"
                glowColor="purple"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                JOIN DISCORD
              </AnimatedButton>
            </div>
          </div>
        </div>
      </SectionContainer>

      {/* About Section */}
      <SectionContainer id="about" background="dark">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            ABOUT THE GAME
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-purple-500 mx-auto mb-8"></div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-blue-300">
              Enter the World of Anime Clash Battleground
            </h3>
            <p className="text-gray-300 text-lg leading-relaxed">
              Anime Clash Battleground brings your favorite anime characters to life in an epic fighting experience. 
              Battle across stunning anime-inspired environments, master unique character abilities, and engage in 
              intense PvP combat that will test your skills to the limit.
            </p>
            <p className="text-gray-300 text-lg leading-relaxed">
              Whether you're a seasoned fighter or new to the battlefield, our game offers something for everyone. 
              Unlock powerful transformations, collect rare items, and climb the leaderboards to prove you're the 
              ultimate anime warrior.
            </p>
            <div className="flex flex-wrap gap-3 pt-4">
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/50">Epic Battles</Badge>
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/50">Anime Powers</Badge>
              <Badge className="bg-pink-500/20 text-pink-300 border-pink-500/50">PvP Combat</Badge>
              <Badge className="bg-cyan-500/20 text-cyan-300 border-cyan-500/50">Transformations</Badge>
            </div>
          </div>

          <div className="relative">
            <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-blue-500/30 overflow-hidden">
              <CardContent className="p-8">
                <div className="aspect-video bg-gradient-to-br from-blue-900/50 to-purple-900/50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Play className="h-16 w-16 text-blue-400 mx-auto mb-4" />
                    <p className="text-blue-300 font-semibold">Game Preview Coming Soon</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </SectionContainer>

      {/* Features Section */}
      <SectionContainer id="features" background="gradient">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            GAME FEATURES
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto mb-8"></div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Discover what makes Anime Clash Battleground the ultimate fighting experience
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Sword className="h-8 w-8" />}
            title="Epic Combat System"
            description="Master devastating combos, special attacks, and ultimate abilities inspired by your favorite anime series."
          />
          
          <FeatureCard
            icon={<Zap className="h-8 w-8" />}
            title="Unique Transformations"
            description="Unlock powerful transformations that change your appearance and grant incredible new abilities."
          />
          
          <FeatureCard
            icon={<Users className="h-8 w-8" />}
            title="Multiplayer Battles"
            description="Fight against players worldwide in intense PvP matches and prove your dominance."
          />
          
          <FeatureCard
            icon={<Trophy className="h-8 w-8" />}
            title="Competitive Rankings"
            description="Climb the leaderboards and earn exclusive rewards as you become the ultimate champion."
          />
          
          <FeatureCard
            icon={<ExternalLink className="h-8 w-8" />}
            title="Anime-Inspired Maps"
            description="Battle across beautifully crafted environments inspired by iconic anime locations."
          />
          
          <FeatureCard
            icon={<MessageCircle className="h-8 w-8" />}
            title="Active Community"
            description="Join thousands of players in our Discord community for events, updates, and tournaments."
          />
        </div>
      </SectionContainer>

      {/* Gallery Section */}
      <SectionContainer id="gallery" background="dark">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
            GALLERY & TRAILER
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-green-500 to-blue-500 mx-auto mb-8"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="group bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-blue-500/30 overflow-hidden hover:scale-105 transition-transform duration-300">
              <CardContent className="p-0">
                <div className="aspect-video bg-gradient-to-br from-blue-900/50 to-purple-900/50 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <Play className="h-12 w-12 text-blue-400 group-hover:text-white transition-colors duration-300 relative z-10" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <AnimatedButton 
            href="https://youtube.com/@animeclashbattleground"
            variant="outline"
            size="lg"
            className="border-red-500 text-red-300 hover:bg-red-500/20 font-bold"
            glowColor="purple"
          >
            <Youtube className="mr-2 h-5 w-5" />
            WATCH ON YOUTUBE
          </AnimatedButton>
        </div>
      </SectionContainer>

      {/* Community Section */}
      <SectionContainer id="community" background="gradient">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            JOIN OUR COMMUNITY
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-purple-500 to-pink-500 mx-auto mb-8"></div>
          
          <div className="max-w-4xl mx-auto">
            <Card className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-purple-500/30 overflow-hidden">
              <CardContent className="p-12 text-center">
                <MessageCircle className="h-20 w-20 text-purple-400 mx-auto mb-6" />
                <h3 className="text-3xl font-bold mb-4 text-purple-300">
                  Connect with Fellow Warriors
                </h3>
                <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                  Join our Discord server to stay updated with the latest news, participate in tournaments, 
                  find teammates, and connect with the amazing Anime Clash Battleground community!
                </p>
                
                <div className="grid sm:grid-cols-3 gap-6 mb-8">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">10K+</div>
                    <div className="text-gray-400">Active Members</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">24/7</div>
                    <div className="text-gray-400">Community Support</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-pink-400">Weekly</div>
                    <div className="text-gray-400">Tournaments</div>
                  </div>
                </div>

                <AnimatedButton 
                  href="https://discord.gg/BNMjDbmVRH"
                  size="lg"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold px-12 py-4 text-xl"
                  glowColor="purple"
                >
                  <MessageCircle className="mr-3 h-6 w-6" />
                  JOIN DISCORD NOW
                </AnimatedButton>
              </CardContent>
            </Card>
          </div>
        </div>
      </SectionContainer>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-6">
              Anime Clash Battleground
            </h3>
            
            <div className="flex justify-center space-x-6 mb-8">
              <AnimatedButton 
                href="https://www.roblox.com/games/placeholder"
                variant="ghost"
                className="text-gray-400 hover:text-blue-400"
              >
                <ExternalLink className="h-6 w-6" />
              </AnimatedButton>
              
              <AnimatedButton 
                href="https://discord.gg/BNMjDbmVRH"
                variant="ghost"
                className="text-gray-400 hover:text-purple-400"
              >
                <MessageCircle className="h-6 w-6" />
              </AnimatedButton>
              
              <AnimatedButton 
                href="https://youtube.com/@animeclashbattleground"
                variant="ghost"
                className="text-gray-400 hover:text-red-400"
              >
                <Youtube className="h-6 w-6" />
              </AnimatedButton>
            </div>
            
            <div className="text-gray-500 text-sm">
              <p>&copy; 2024 Anime Clash Battleground. All rights reserved.</p>
              <p className="mt-2">Built with ❤️ for the anime gaming community</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}