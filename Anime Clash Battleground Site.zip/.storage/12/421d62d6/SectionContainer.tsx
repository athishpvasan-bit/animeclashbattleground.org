import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface SectionContainerProps {
  children: ReactNode;
  className?: string;
  id?: string;
  background?: "default" | "gradient" | "dark";
}

export function SectionContainer({ 
  children, 
  className, 
  id,
  background = "default" 
}: SectionContainerProps) {
  const backgroundClasses = {
    default: "bg-slate-900",
    gradient: "bg-gradient-to-br from-slate-900 via-blue-900/20 to-purple-900/20",
    dark: "bg-slate-950"
  };

  return (
    <section 
      id={id}
      className={cn(
        "py-16 px-4 sm:px-6 lg:px-8",
        backgroundClasses[background],
        className
      )}
    >
      <div className="mx-auto max-w-7xl">
        {children}
      </div>
    </section>
  );
}