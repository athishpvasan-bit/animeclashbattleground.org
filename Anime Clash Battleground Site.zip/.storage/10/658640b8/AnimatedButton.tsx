import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface AnimatedButtonProps {
  children: ReactNode;
  className?: string;
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
  href?: string;
  onClick?: () => void;
  glowColor?: string;
}

export function AnimatedButton({ 
  children, 
  className, 
  variant = "default", 
  size = "default",
  href,
  onClick,
  glowColor = "blue"
}: AnimatedButtonProps) {
  const baseClasses = cn(
    "relative overflow-hidden transition-all duration-300 transform hover:scale-105",
    "before:absolute before:inset-0 before:bg-gradient-to-r before:opacity-0 hover:before:opacity-20",
    "after:absolute after:inset-0 after:bg-gradient-to-r after:opacity-0 hover:after:opacity-10",
    glowColor === "blue" && "before:from-blue-400 before:to-cyan-400 after:from-purple-400 after:to-pink-400",
    glowColor === "purple" && "before:from-purple-400 before:to-pink-400 after:from-blue-400 after:to-cyan-400",
    glowColor === "green" && "before:from-green-400 before:to-emerald-400 after:from-blue-400 after:to-cyan-400",
    "shadow-lg hover:shadow-xl",
    className
  );

  if (href) {
    return (
      <Button 
        variant={variant} 
        size={size} 
        className={baseClasses}
        asChild
      >
        <a href={href} target="_blank" rel="noopener noreferrer">
          <span className="relative z-10">{children}</span>
        </a>
      </Button>
    );
  }

  return (
    <Button 
      variant={variant} 
      size={size} 
      className={baseClasses}
      onClick={onClick}
    >
      <span className="relative z-10">{children}</span>
    </Button>
  );
}