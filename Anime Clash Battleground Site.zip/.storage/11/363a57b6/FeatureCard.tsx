import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  className?: string;
}

export function FeatureCard({ icon, title, description, className }: FeatureCardProps) {
  return (
    <Card className={cn(
      "group relative overflow-hidden border-0 bg-gradient-to-br from-slate-900/50 to-slate-800/50",
      "backdrop-blur-sm transition-all duration-500 hover:scale-105",
      "before:absolute before:inset-0 before:bg-gradient-to-br before:from-blue-500/10 before:to-purple-500/10",
      "before:opacity-0 hover:before:opacity-100 before:transition-opacity before:duration-500",
      "shadow-lg hover:shadow-2xl hover:shadow-blue-500/25",
      className
    )}>
      <CardContent className="relative p-6 text-center">
        <div className="mb-4 flex justify-center">
          <div className="rounded-full bg-gradient-to-br from-blue-500 to-purple-600 p-3 text-white transition-transform duration-300 group-hover:scale-110">
            {icon}
          </div>
        </div>
        <h3 className="mb-2 text-xl font-bold text-white group-hover:text-blue-300 transition-colors duration-300">
          {title}
        </h3>
        <p className="text-gray-300 text-sm leading-relaxed">
          {description}
        </p>
      </CardContent>
    </Card>
  );
}